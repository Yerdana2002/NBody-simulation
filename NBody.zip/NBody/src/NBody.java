public class NBody {
    // Takes 2 command line args. Duration of the simulation T and time increments delta T.
    // Reads input as universe file using StdIn
    // Writes the state of the universe in same format as input to output file when program finishes


    //Step 1: Parsing command line arguments
    public static void main(String[] args) {
        double tea = Double.parseDouble(args[0]);   // Total runtime of the program
        double tau = Double.parseDouble(args[1]);   // Time increments
        //Step 2: Reading values using StdIn
        int n = StdIn.readInt();    // number of bodies in txt file
        double radius = StdIn.readDouble();

        double[] px = new double[n];     //array with x positions of each element
        double[] py = new double[n];     //array with y positions of each element
        double[] vx = new double[n];     //array with x velocities of each element
        double[] vy = new double[n];     //array with y velocities of each element
        double[] mass = new double[n];   //array with masses of each element
        String[] image = new String[n];  //array with text names of each element


        //reading data from the text file to store in arrays
        for (int i = 0; i < n; i++) {
            px[i] = StdIn.readDouble();
            py[i] = StdIn.readDouble();
            vx[i] = StdIn.readDouble();
            vy[i] = StdIn.readDouble();
            mass[i] = StdIn.readDouble();
            image[i] = StdIn.readString();

        }
        /*for (int i = 0; i < n; i++) {
            StdOut.print(image[i]);
        }*/    //code to test contents of array image[i].

        //Step 6: Printing universe data to StdOut
        StdOut.printf("%d\n", n);
        StdOut.printf("%.2e\n", radius);
        for (int i = 0; i < n; i++) {
            StdOut.printf("%11.4e %11.4e %11.4e %11.4e %11.4e %12s\n",
                    px[i], py[i], vx[i], vy[i], mass[i], image[i]);
        }


        //Step 3: Initializing standard drawing
        StdDraw.setXscale(-radius, radius);
        StdDraw.setYscale(-radius, radius);
        StdDraw.enableDoubleBuffering();

        //Step 4: Playing background music
        //StdAudio.play("2001.wav");


        double t = 0;
        final double G = 6.67e-11;
        //Initializing arrays fx and fy that store net forces to bodies i in x and y directions
        double[] fx = new double[n];
        double[] fy = new double[n];
        double[] ax = new double[n];
        double[] ay = new double[n];
        while (t < tea) {
            //Step 5: Simulating the universe with loop
            //Step 5A: Calculating forces
            for (int i = 0; i < n; i++) {
                fx[i] = 0;
                fy[i] = 0;
            }
            // Calculating forces acting upon body i from body j using nested loops

            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (i == j)
                        continue;
                    else {
                        double distance = Math.pow((Math.pow((px[i] - px[j]), 2) + Math.pow((py[i] - py[j]), 2)), 0.5);
                        double cosa = (px[j] - px[i]) / distance;
                        double sina = (py[j] - py[i]) / distance;
                        fx[i] = fx[i] + ((mass[j] * mass[i] * G) / Math.pow(distance, 2)) * cosa;
                        fy[i] = fy[i] + ((mass[j] * mass[i] * G) / Math.pow(distance, 2)) * sina;
                    }

                }
            }


            //Step 5B: Calculating velocities and positions
            //Calculating acceleration of each particle
            for (int i = 0; i < n; i++) {
                ax[i] = fx[i] / mass[i];
                ay[i] = fy[i] / mass[i];
            }

            for (int i = 0; i < n; i++) {
                vx[i] = vx[i] + ax[i] * tau;
                vy[i] = vy[i] + ay[i] * tau;
                px[i] = px[i] + vx[i] * tau;
                py[i] = py[i] + vy[i] * tau;
            }

            //Step 5C: Animating the result using StdDraw
            StdDraw.picture(0, 0, "starfield.jpg");
            //Loop to display n particles
            for (int i = 0; i < n; i++)
                StdDraw.picture(px[i], py[i], image[i]);

            StdDraw.show();
            StdDraw.pause(20);
            t += tau;
        }


    }
}
