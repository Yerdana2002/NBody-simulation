Programming Assignment: N-Body Simulation


PLEASE REMEMBER NOT TO INCLUDE YOUR NAME (OR LATER IN THE COURSE, YOUR
PARTNER'S NAME) ANYWHERE IN THIS SUBMISSION.


/**********************************************************************
 * Approximate number of hours to complete this assignment            *
 **********************************************************************/

Number of hours:



/**********************************************************************
 *  Did you receive help from classmates, past COS 126 students, or
 *  anyone else? If so, please list their names.  ("A Sunday lab TA"
 *  or "Office hours on Thursday" is ok if you don't know their name.)
 **********************************************************************/

Yes or no?   
Names:


/**********************************************************************
 *  Did you encounter any serious problems? If so, please describe.
 **********************************************************************/

Describe:



/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/



/**********************************************************************
 *  If you attempted Challenge #1, and submitted deluxe-universe.txt,
 *  please explain your work and approach; in particular explain how
 *  you figured out which values to put in the file to get your desired
 *  result.
 **********************************************************************/

Describe:


/**********************************************************************
 *  If you attempted Challenge #2, and submitted DeluxeNBody.java,
 *  please register an account on https://www.loom.com, record a 2-min.
 *  video of yourself showing your universe in action, and explain what
 *  you are doing.
 **********************************************************************/

Link to Loom video:

